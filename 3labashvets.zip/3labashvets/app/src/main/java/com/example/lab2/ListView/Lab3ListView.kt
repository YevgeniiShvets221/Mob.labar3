package com.example.lab2.ListView

import android.content.Intent
import android.os.Bundle
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity
import com.example.lab2.MainActivity
import com.example.lab2.MusicBand
import com.example.lab2.R
import kotlinx.android.synthetic.main.activity_lab3_list_view.*

class Lab3ListView : AppCompatActivity() {

    //Создание объекта
    private var band: MutableList<MusicBand> = ArrayList()

    @Suppress("NULLABILITY_MISMATCH_BASED_ON_JAVA_ANNOTATIONS")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lab3_list_view)
        title = "Lab3 ListView"

        //Добавление информации о группах
        val list: ListView = list_view // Віджет ListView
        band.add(MusicBand(R.drawable.nickelback, "Nickleback", "rock", 1995, "канадская альтернативная рок-группа, основанная в 1995 году в городе Ханна (англ.). Группа состоит из гитариста и вокалиста Чеда Крюгера; гитариста, клавишника и бэк-вокалиста Райана Пик; басиста Майка Крюгера и барабанщика Дэниеля Адэра. "))
        band.add(MusicBand(R.drawable.hardkiss, "The Hardkiss", "rock", 2011, "украинская рок-группа, появившаяся в 2011 году. Авторство всех песен группы принадлежит её участникам — Юлии Саниной и Валерию Бебко, который также выступает креативным продюсером The Hardkiss. Над образами участников группы работают стилисты Слава Чайка и Виталик Дацюк."))
        //СОздание объекта
        val myAdapter = Adapter(this, band)
        list.adapter = myAdapter // передаем его к виджету списка

        // Создание кнопки
        back.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
        }
        }
    }

