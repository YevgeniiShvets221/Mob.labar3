package com.example.lab2.RecycleView

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.lab2.MainActivity
import com.example.lab2.MusicBand
import com.example.lab2.R
import kotlinx.android.synthetic.main.activity_lab3_recycler_view.back


class Lab3RecyclerView : Activity() {

    //Изменение адаптера и менеджера
    private lateinit var recyclerView: RecyclerView
    private lateinit var viewAdapter: RecyclerView.Adapter<*>
    private lateinit var viewManager: RecyclerView.LayoutManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lab3_recycler_view)
        title = "Lab3 RecyclerView"

        val band: MutableList<MusicBand> = ArrayList() // создание и заполнение объектов класса People
        band.add(MusicBand(R.drawable.nickelback, "Nickleback", "rock", 1995, "канадская альтернативная рок-группа, основанная в 1995 году в городе Ханна (англ.). Группа состоит из гитариста и вокалиста Чеда Крюгера; гитариста, клавишника и бэк-вокалиста Райана Пик; басиста Майка Крюгера и барабанщика Дэниеля Адэра. "))
        band.add(MusicBand(R.drawable.hardkiss, "The Hardkiss", "rock", 2011, "украинская рок-группа, появившаяся в 2011 году. Авторство всех песен группы принадлежит её участникам — Юлии Саниной и Валерию Бебко, который также выступает креативным продюсером The Hardkiss. Над образами участников группы работают стилисты Слава Чайка и Виталик Дацюк."))

        // Позиционирование всех элементов
        viewManager = LinearLayoutManager(this)
        //Адаптер
        viewAdapter = Adapter(band)
        // ССылка на объект
        recyclerView = findViewById<RecyclerView>(R.id.recyclerview).apply {
            setHasFixedSize(true) // Розмір RecyclerView не будет меняться
            layoutManager = viewManager
            adapter = viewAdapter
        }

        // Создание кнопки
        back.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
        }

    }
}
